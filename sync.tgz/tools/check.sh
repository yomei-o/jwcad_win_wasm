#!/bin/sh
# Build everything and check it against the original, pixel for pixel.
#
#   sh tools/check.sh
#
# Needs src/gen/ built first, from your own copy of the installer:
#   python tools/mkres.py  orig/Jw_win.exe src/gen --maxh 21
#   python tools/btnmap.py docs/ref_start.png decomp/res/bitmap src/gen/layout.h
#   python tools/mkfont.py font src/gen
#   python tools/mknew.py  decomp/res/new.jww src/gen
#   python tools/mksunpo.py
#   python tools/mkzoku.py
set -e
cd "$(dirname "$0")/.."
# node comes with emsdk and is not on PATH there.  Where it sits inside the
# node package moved: the 22 series has it under bin/, the 24 series at the
# top, so look in both.
if ! command -v node >/dev/null 2>&1; then
    for d in "${EMSDK:-/c/prog/emsdk/emsdk}"/node/*/bin              "${EMSDK:-/c/prog/emsdk/emsdk}"/node/*; do
        [ -x "$d/node.exe" ] && { PATH="$d:$PATH"; export PATH; break; }
    done
fi
[ -f src/gen/jwres.c ]  || { echo "run tools/mkres.py first";  exit 1; }
[ -f src/gen/layout.h ] || { echo "run tools/btnmap.py first"; exit 1; }
[ -f src/gen/jwfont.c ] || { echo "run tools/mkfont.py first"; exit 1; }
[ -f src/gen/newjww.c ] || { echo "run tools/mknew.py first";  exit 1; }
[ -f src/gen/sunpo.h ]  || { echo "run tools/mksunpo.py first"; exit 1; }
[ -f src/gen/zoku.h ]   || { echo "run tools/mkzoku.py first";  exit 1; }
[ -f src/gen/moji.h ]   || { echo "run tools/mkmoji.py first";  exit 1; }
[ -f src/gen/zokusel.h ] || { echo "run tools/mkzokusel.py first"; exit 1; }
[ -f src/gen/zokuhen.h ] || { echo "run tools/mkzokuhen.py first"; exit 1; }
[ -f src/gen/blkname.h ] || { echo "run tools/mkblkname.py first"; exit 1; }
[ -f src/gen/blkedit.h ] || { echo "run tools/mkblkedit.py first"; exit 1; }
[ -f src/gen/kihon.h ]   || { echo "run tools/mkkihon.py first";   exit 1; }
[ -f src/gen/jikkaku.h ] || { echo "run tools/mkjikkaku.py first"; exit 1; }
[ -f src/gen/sunpodlg.h ] || { echo "run tools/mksunpodlg.py first"; exit 1; }
[ -f src/gen/bairitsu.h ] || { echo "run tools/mkbairitsu.py first"; exit 1; }

sh tools/build_tests.sh
sh tools/build_native.sh
sh tools/build_wasm.sh

# tests/figreg_test.c is scored against a figure the original made out of
# this drawing, so it has to be the same one tools/refanswers.sh drove with.
if [ ! -f tmp/geom.jww ]; then
    mkdir -p tmp
    # in a subshell, because putting w64devkit in front of PATH here would
    # also put its busybox sh, python and node in front of the real ones for
    # the rest of this script
    (
        if [ -z "$CC" ] && ! command -v gcc >/dev/null 2>&1; then
            for d in /c/prog/w64devkit/bin /c/prog/tools/w64devkit/bin; do
                [ -x "$d/gcc.exe" ] && { PATH="$d:$PATH"; export PATH; break; }
            done
        fi
        ${CC:-gcc} -O2 -Isrc -o tmp/mkgeom.exe tools/mkgeom.c src/jww.c             src/jwwrite.c src/cp932.c && ./tmp/mkgeom.exe orig/Test5.jww tmp/geom.jww
    )
fi

echo
echo "=== 図形ファイル (.jws) —— 同梱の図形が末尾ぴったりで読めて、そのまま書き戻せるか"
# Both levels: the six folders themselves and the subfolders under them
# (人物, 樹木, 車, ２．５Ｄ用, 木造平面) -- 341 figures, not the 189 the
# top level alone has.
JWS="orig/*/*.jws orig/*/*.JWS orig/*/*/*.jws orig/*/*/*.JWS"
printf '    %s\n' "$(./tests/jws_test.exe $JWS 2>/dev/null | tail -1)"
./tests/jws_test.exe $JWS 2>/dev/null | grep '^BAD' || true

echo
echo "=== 壊れたファイル —— 読み手が落ちず、いつまでも回らないか"
./tests/fuzz_test.exe orig/*.jww decomp/res/*.jww $JWS     decomp/res/*.dxf decomp/res/*.sfc decomp/res/*.jwc 2>/dev/null     | sed 's/^/    /'

echo
echo "=== 手当たり次第にコマンドを叩く —— 落ちず、数が壊れないか"
./tests/cmdfuzz_test.exe orig/Test1.jww orig/Test5.jww orig/Test7.jww     2>/dev/null | sed 's/^/    /'
./tests/cmdfuzz_test.exe 2>/dev/null | sed 's/^/    from nothing: /'

echo
echo "=== the .jww reader: every drawing lands on the end of its file"
# Jw_cad's own sixteen, and every answer the original has written for this
# port besides: a hundred and fifty more drawings in every state the tests
# have ever put it in, which is a far wider sample of the format.
printf '    %s of %s\n' \
    "$(./tests/jww_test.exe orig/*.jww decomp/res/*.jww | grep -c '^ok')" \
    "$(ls orig/*.jww decomp/res/*.jww | wc -l)"
./tests/jww_test.exe orig/*.jww decomp/res/*.jww | grep '^BAD' || true

echo
echo "=== writing a drawing back out: the bytes have to be identical"
# The same wide set, with decomp/res/sfcgeo.jww left out: that one came in
# through 読取 from an SFC, so its arcs still carry a start angle outside
# (-pi, pi] (0x45ac is just over 3pi/2), and the reader brings them in the
# way the original does when it loads a drawing -- decomp/res/zhlayer.jww is
# the original's own proof of that.  So that file is written back different
# in one double on purpose, and the original would do the same to it.
WRITE="$(ls orig/*.jww decomp/res/*.jww | grep -v 'sfcgeo')"
./tests/write_test.exe $WRITE | grep -c '^ok' | sed 's/^/    /'
./tests/write_test.exe $WRITE | grep '^BAD' || true

echo
echo "=== what is under the mouse"
for f in orig/*.jww; do
    ./tests/pick_test.exe "$f" | grep '^BAD' | sed "s|^|    $(basename "$f") |"
done
printf '    %s of %s drawings
'     "$(for f in orig/*.jww; do ./tests/pick_test.exe "$f" | tail -1; done | grep -c '^all ok')"     "$(ls orig/*.jww | wc -l)"

echo
echo "=== the (R) read point, against Jw_cad's own answers"
./tests/read_test.exe orig/Test5.jww | sed 's/^/    /'

echo
echo "=== pressing things"
./tests/click_test.exe orig/Test1.jww | sed 's/^/    /'

echo
echo "=== 線属性のダイアログ"
./tests/zoku_test.exe tests/out/zoku.png | sed 's/^/    /'
python tools/cmp.py docs/ref_zoku.png tests/out/zoku.png     -i docs/zoku_textareas.txt -d tests/out/zoku.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 書込み文字種変更 —— 原典が描いたダイアログとの突き合わせ"
./tests/moji_test.exe tests/out/moji.png | sed 's/^/    /'
python tools/cmp.py docs/ref_moji.png tests/out/moji.png \
    -i docs/moji_textareas.txt -d tests/out/moji.diff.png \
    | head -2 | sed 's/^/    /'

echo
echo "=== ブロック化 —— ダイアログと、原典が作った定義との突き合わせ"
./tests/blkmake_test.exe tests/out/blkname.png | sed 's/^/    /'
python tools/cmp.py docs/ref_blkname.png tests/out/blkname.png     -i docs/blkname_textareas.txt -d tests/out/blkname.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 寸法設定 —— 原典が描いたダイアログとの突き合わせ"
./tests/sunpodlg_test.exe tests/out/sunpodlg.png | sed 's/^/    /'
python tools/cmp.py docs/ref_sunpodlg.png tests/out/sunpodlg.png     -i docs/sunpodlg_textareas.txt -d tests/out/sunpodlg.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 座標ファイル —— 原典が書いた座標ファイルとのバイト突き合わせ"
./tests/coord_test.exe | sed 's/^/    /'

echo
echo "=== 中心点取得 —— 線の中点・円の中心を読ませたものとの突き合わせ"
./tests/snap_test.exe | sed 's/^/    /'

echo
echo "=== 属性選択・属性変更の「指定」—— 線属性ダイアログで選んだ色・線種"
./tests/zokattr_test.exe | sed 's/^/    /'

echo
echo "=== 図形登録 —— 原典が書いた .jws とのバイト突き合わせ"
./tests/figreg_test.exe | sed 's/^/    /'

echo
echo "=== 図形読込 —— 原典が置いた図形との突き合わせ"
./tests/figure_test.exe | sed 's/^/    /'

echo
echo "=== 画面倍率・文字表示 —— 原典が描いたダイアログとの突き合わせ"
./tests/bairitsu_test.exe tests/out/bairitsu.png | sed 's/^/    /'
python tools/cmp.py docs/ref_bairitsu.png tests/out/bairitsu.png     -i docs/bairitsu_textareas.txt -d tests/out/bairitsu.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 軸角 —— ダイアログと、原典が引いた軸上の線との突き合わせ"
./tests/jikkaku_test.exe tests/out/jikkaku.png | sed 's/^/    /'
python tools/cmp.py docs/ref_jikkaku.png tests/out/jikkaku.png     -i docs/jikkaku_textareas.txt -d tests/out/jikkaku.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 基本設定 —— 原典が描いた 8 枚のタブとの突き合わせ"
./tests/kihon_test.exe tests/out/kihon.png | sed 's/^/    /'
for t in 1 2 3 4 5 6 7 8; do
    m=docs/kihon_textareas.txt
    [ $t = 1 ] || m=docs/kihon_textareas$t.txt
    printf '    %s: ' "$t"
    python tools/cmp.py docs/ref_kihon$t.png tests/out/kihon$t.png         -i $m -d tests/out/kihon$t.diff.png | sed -n '2p'
done

echo
echo "=== ブロック編集 —— ダイアログと、原典が変えた定義との突き合わせ"
./tests/blkedit_test.exe tests/out/blkedit.png | sed 's/^/    /'
python tools/cmp.py docs/ref_blkedit.png tests/out/blkedit.png     -i docs/blkedit_textareas.txt -d tests/out/blkedit.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 用紙サイズ —— 原典が変えた用紙との突き合わせ"
./tests/paper_test.exe | sed 's/^/    /'

echo
echo "=== データ整理 —— 原典の重複整理・連結整理との突き合わせ"
./tests/seiri_test.exe | sed 's/^/    /'

echo
echo "=== 属性変更（範囲から） —— ダイアログと、原典が変えたものとの突き合わせ"
./tests/zokuhen2_test.exe tests/out/zokuhen.png | sed 's/^/    /'
python tools/cmp.py docs/ref_zokuhen.png tests/out/zokuhen.png     -i docs/zokuhen_textareas.txt -d tests/out/zokuhen.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 属性選択 —— ダイアログと、原典の選び方との突き合わせ"
./tests/zokusel_test.exe tests/out/zokusel.png | sed 's/^/    /'
python tools/cmp.py docs/ref_zokusel.png tests/out/zokusel.png     -i docs/zokusel_textareas.txt -d tests/out/zokusel.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== 接線 —— 原典が引いた 4 本の共通接線との突き合わせ"
./tests/sessen_test.exe | sed 's/^/    /'

echo
echo "=== 接円 —— 原典が描いた 4 つの接円との突き合わせ"
./tests/sekien_test.exe | sed 's/^/    /'

echo
echo "=== 曲線 —— 原典が描いたスプラインとの突き合わせ"
./tests/curve_test.exe | sed 's/^/    /'

echo
echo "=== ハッチ —— 原典が引いたハッチとの突き合わせ"
./tests/hatch_test.exe | sed 's/^/    /'

echo
echo "=== 包絡処理 —— 原典が包絡した 9 通りとの突き合わせ"
./tests/houraku_test.exe | sed 's/^/    /'

echo
echo "=== 中心線 —— 原典が引いた中心線との突き合わせ"
./tests/chushin_test.exe | sed 's/^/    /'

echo
echo "=== 属性変更 —— 原典が変えた要素との突き合わせ"
./tests/zokuhen_test.exe | sed 's/^/    /'

echo
echo "=== 複写・移動の倍率と回転角 —— 原典が置いたものとの突き合わせ"
./tests/xform_test.exe | sed 's/^/    /'

echo
echo "=== DXF 書き出し —— 原典が書いた DXF との突き合わせ"
./tests/dxf_test.exe | sed 's/^/    /'

echo
echo "=== DXF 読み込み —— 原典が同じ DXF を開いた結果との突き合わせ"
./tests/dxfread_test.exe | sed 's/^/    /'

echo
echo "=== SFC 読み込み —— 原典が同じ SFC を開いた結果との突き合わせ"
./tests/sfcread_test.exe | sed 's/^/    /'

echo
echo "=== SFC 書き出し —— 原典が書いた SFC との 1 バイトずつの突き合わせ"
./tests/sfcwrite_test.exe | sed 's/^/    /'

echo
echo "=== JWC 読み込み —— 原典が同じ JWC を開いた結果との突き合わせ"
./tests/jwcread_test.exe | sed 's/^/    /'

echo
echo "=== JWC 書き出し —— 原典が書いた JWC との 1 バイトずつの突き合わせ"
./tests/jwcwrite_test.exe | sed 's/^/    /'

echo
echo "=== 図形 —— 参照が定義をその場所・倍率・回転で描くか"
./tests/block_test.exe | sed 's/^/    /'

echo
echo "=== ２線 —— 原典が引いた 2 本との突き合わせ"
./tests/nisen_test.exe | sed 's/^/    /'

echo
echo "=== 分割 —— 原典が引いた等分線との突き合わせ"
./tests/bunkatsu_test.exe | sed 's/^/    /'

echo
echo "=== 面取 —— 原典が切った角との突き合わせ"
./tests/mentori_test.exe | sed 's/^/    /'

echo
echo "=== 多角形 —— 原典が描いた八角形との突き合わせ"
./tests/poly_test.exe | sed 's/^/    /'

echo
echo "=== 寸法 —— 原典が描いた寸法との突き合わせ"
./tests/sunpo_test.exe | sed 's/^/    /'

echo
echo "=== メニュー —— ブラウザ版が自分で開くポップアップ"
./tests/menu_test.exe tests/out/menu.png | sed 's/^/    /'

echo
echo "=== レイヤとレイヤグループの格子"
./tests/layer_test.exe orig/Test5.jww | sed 's/^/    /'

echo
echo "=== 範囲選択・複写・移動"
./tests/sel_test.exe orig/Test5.jww | sed 's/^/    /'

echo
echo "=== a drawing begun from nothing, drawn on and saved"
./tests/new_test.exe tests/out/new.jww | sed 's/^/    /'

./tests/frame.exe tests/out/frame.png >/dev/null
node tests/wasm_check.js tests/out/wasm.png >/dev/null

echo
echo "=== ひと続きの作業 —— 新規から保存まで"
./tests/session_test.exe tests/out/session.jww | sed 's/^/    /'

echo
echo "=== the frame against the original"
python tools/cmp.py docs/ref_start.png tests/out/frame.png \
    -i docs/textareas.txt -d tests/out/diff.png | head -2 | sed 's/^/    /'

echo
echo "=== 別の大きさの枠 —— 右端と下端に付いてくるか"
python tools/mkmask.py docs/textareas.txt 1484 841 tests/out/mask_big.txt >/dev/null
./tests/frame.exe tests/out/frame_big.png 1484 841 >/dev/null
python tools/cmp.py docs/ref_start_big.png tests/out/frame_big.png     -i tests/out/mask_big.txt -d tests/out/big.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== キャプションとメニューバー（ブラウザ版が自分で描く分）"
node tests/wasm_check.js tests/out/chrome.png 1264 741 --chrome >/dev/null
python -c "from PIL import Image; Image.open('docs/ref_window.png').convert('RGB').crop((8,0,1272,51)).save('tests/out/chrome_ref.png'); Image.open('tests/out/chrome.png').convert('RGB').crop((0,0,1264,51)).save('tests/out/chrome_top.png')"
python tools/cmp.py tests/out/chrome_ref.png tests/out/chrome_top.png     -i docs/chrome_textareas.txt -d tests/out/chrome.diff.png     | head -2 | sed 's/^/    /'

echo
echo "=== native against WASM, pixel for pixel"
python tools/cmp.py tests/out/frame.png tests/out/wasm.png \
    -d tests/out/nw.diff.png | head -1 | sed 's/^/    /'
# and with a drawing in it, not just the empty frame: the two builds go
# through the same src/*.c, so anything that differs is the port leaning on
# the machine under it
for n in 1 7; do
    ./tests/shot.exe tests/out/test$n.png orig/Test$n.jww >/dev/null
    node tests/wasm_check.js tests/out/wasm_test$n.png 1264 741 \
        --open orig/Test$n.jww >/dev/null
    python tools/cmp.py tests/out/test$n.png tests/out/wasm_test$n.png \
        -d tests/out/nw$n.diff.png | head -1 | sed 's/^/    /'
done

echo
echo "=== 同梱の図面をぜんぶ描いてみる —— 落ちないか、両方で同じか"
# Every drawing, both ways round: the native build and the WebAssembly one
# go through the same src/*.c, so a drawing that comes out differently is
# the port leaning on the machine under it (a long double somewhere, a
# signed char, an int that is 64 bits on one side).  Test1 and Test7 alone
# used to be the whole of this.
n=0
rm -rf tests/out/nat tests/out/wasmall
mkdir -p tests/out/nat
: > tests/out/all.lst
for f in orig/*.jww; do
    if ./tests/shot.exe "tests/out/nat/$(basename "$f").png" "$f" \
            >/dev/null 2>&1; then
        n=$((n + 1))
        printf '%s\n' "$f" >> tests/out/all.lst
    else
        echo "    BAD  $f"
    fi
done
printf '    %s of %s drawn\n' "$n" "$(ls orig/*.jww | wc -l)"

# The WebAssembly side draws the lot from one start of node: loading the
# module costs far more than a drawing does.
if command -v node >/dev/null 2>&1; then
    same=0
    tried=0
    node tests/wasm_check.js --each tests/out/all.lst tests/out/wasmall \
        1264 741 >/dev/null 2>&1
    while IFS= read -r f; do
        [ -n "$f" ] || continue
        b=$(basename "$f")
        tried=$((tried + 1))
        if [ ! -f "tests/out/wasmall/$b.png" ]; then
            echo "    BAD  $f: the WebAssembly build will not draw it"
            continue
        fi
        if python tools/cmp.py "tests/out/nat/$b.png" \
                "tests/out/wasmall/$b.png" 2>/dev/null |
                head -1 | grep -q ' 0 of '; then
            same=$((same + 1))
        else
            echo "    BAD  $f: native and WebAssembly draw it differently"
            python tools/cmp.py "tests/out/nat/$b.png" \
                "tests/out/wasmall/$b.png" | head -1 | sed 's/^/         /'
        fi
    done < tests/out/all.lst
    printf '    %s of %s the same in both builds\n' "$same" "$tried"
fi

echo
echo "=== drawings against the original"
echo "    the glyphs cannot match -- the original draws them with a Windows"
echo "    font -- so the text rectangles are scored separately"
for n in 1 7; do
    ./tests/shot.exe tests/out/test$n.png orig/Test$n.jww >/dev/null
    cat docs/textareas.txt tests/out/test$n.png.mask > tests/out/mask$n.txt
    printf '    Test%s  ' $n
    python tools/cmp.py docs/ref_test$n.png tests/out/test$n.png --near \
        -i tests/out/mask$n.txt -d tests/out/test$n.diff.png \
        | sed -n '2p;s/^of those/           --/p'
done

# The fifteen sample drawings, when their reference screens are to hand.
# tools/refshots.sh takes those by driving the original, so they are not in
# the repository and this is skipped on a machine that has not taken them.
if [ -d tmp/refs ] && [ -f tmp/d01.jww ]; then
    echo
    echo '=== 15 枚の採点（tools/scoreall.sh）'
    sh tools/scoreall.sh 2>/dev/null \
        | awk 'NR > 1 { s += $2; line = line $1 "=" $2 " " }
               END { print "    " line; print "    合計 " s " 画素" }'
fi
